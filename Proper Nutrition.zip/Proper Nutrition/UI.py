from tkinter import *

window = Tk()
window.geometry('200x200')

window.mainloop()